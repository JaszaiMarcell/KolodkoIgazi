# Útvonal
[Az első 4 szobor](https://maps.app.goo.gl/CPQZZpYekavsAzFT8)